from manim import *
from manim_slides import Slide

from code.title import title
from code.reinforcement_learning import reinforcement_learning
from code.deep_reinforcement_learning import deep_reinforcement_learning

class Presentation(Slide):
    skip_reversing = False
    def construct(self):
        title(self)
        reinforcement_learning(self)
        deep_reinforcement_learning(self)

